$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"fa4b916d-1a5d-40aa-ae45-33f2e475de91","feature":"Create account on wiki page","scenario":"User creates account on wiki page using input from cucumber data table","start":1701256322244,"group":1,"content":"","tags":"@all,","end":1701256328002,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});